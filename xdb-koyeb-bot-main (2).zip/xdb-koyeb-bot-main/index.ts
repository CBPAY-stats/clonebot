import dotenv from "dotenv";
import fs from "fs";
import http, { IncomingMessage, ServerResponse } from "http";
import TelegramBot from "node-telegram-bot-api";

dotenv.config();

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const CHAT_ID = process.env.TELEGRAM_CHAT_ID || "";
const HORIZON_URL = process.env.HORIZON_URL || "https://horizon.livenet.xdbchain.com";
const DEBUG = (process.env.DEBUG || "").toLowerCase() === "true";

if (!BOT_TOKEN || !CHAT_ID) {
  console.error("❌ Missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID");
  process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: false });

// ===== Par fixo: CBPAY ↔ XDB =====
const CODE_A = "CBPAY";
const CODE_B = "XDB"; // native

// ========= Helpers de ativos/preço =========
function normAsset(code?: string, type?: string) {
  if (code) return String(code).toUpperCase();
  if (type === "native") return "XDB";
  return (type || "").toUpperCase();
}
function isPairCBPAY_XDB(
  buyingCode?: string, buyingType?: string,
  sellingCode?: string, sellingType?: string
) {
  const buy = normAsset(buyingCode, buyingType);
  const sell = normAsset(sellingCode, sellingType);
  return [buy, sell].sort().join("/") === [CODE_A, CODE_B].sort().join("/");
}

type OfferOp = {
  type: string;
  paging_token?: string;
  id?: string;
  transaction_hash?: string;
  buying_asset_code?: string;
  buying_asset_type?: string;
  selling_asset_code?: string;
  selling_asset_type?: string;
  amount?: string;     // SELL: amount of SELLING
  buy_amount?: string; // BUY : amount of BUYING (fallback p/ amount)
  price?: string | number;
  price_r?: { n: number; d: number } | null;
  created_at?: string;
  transaction_hash?: string;
  source_account?: string;
};

const ZWSP = "\u200B"; // Zero-width space para evitar quebras

// ===== Cursor for /operations =====
const CURSOR_FILE = ".offers.ops.cursor";
let cursor = fs.existsSync(CURSOR_FILE) ? fs.readFileSync(CURSOR_FILE, "utf8").trim() : "now";

async function primeCursorIfNeeded() {
  if (cursor !== "now") return;
  try {
    const res = await fetch(`${HORIZON_URL}/operations?order=desc&limit=1`);
    if (!res.ok) throw new Error(`prime ops ${res.status}`);
    const data = await res.json() as any;
    const recs: any[] = data?._embedded?.records ?? [];
    if (recs.length) cursor = recs[0].paging_token || "now";
    fs.writeFileSync(CURSOR_FILE, cursor);
  } catch (e: any) {
    console.error("prime cursor error:", e.message);
  }
}

// ===== Scan loop =====
async function scanOnce() {
  await primeCursorIfNeeded();
  const params = new URLSearchParams({
    cursor: cursor,
    order: "asc", // asc para pegar novos ops
    limit: "100",
    include_failed_data: "true"
  });
  try {
    const res = await fetch(`${HORIZON_URL}/operations?${params}`);
    if (!res.ok) throw new Error(`scan ops ${res.status}`);
    const data = await res.json() as any;
    const recs: OfferOp[] = data?._embedded?.records ?? [];
    for (const op of recs) {
      if (op.type !== "manage_buy_offer_success" && op.type !== "manage_sell_offer_success") continue;
      if (!isPairCBPAY_XDB(op.buying_asset_code, op.buying_asset_type, op.selling_asset_code, op.selling_asset_type)) continue;
      await sendAlert(op);
    }
    if (recs.length) {
      cursor = recs[recs.length - 1].paging_token || cursor;
      fs.writeFileSync(CURSOR_FILE, cursor);
    }
  } catch (e: any) {
    console.error("scan error:", e.message);
  }
}

async function sendAlert(op: OfferOp) {
  const tx = op.transaction_hash;
  const isBuyOp = op.type === "manage_buy_offer_success";

  // ========= Parse price =========
  let rawPrice = op.price;
  let px = toNum(rawPrice);
  if (!px && op.price_r) {
    px = op.price_r.n / op.price_r.d;
    rawPrice = `${op.price_r.n}/${op.price_r.d}`;
  }

  // ========= Parse amounts =========
  let amount = toNum(op.amount); // SELL amount for sell offers, BUY amount for buy offers
  let buy_amount = toNum(op.buy_amount); // BUY amount for buy offers
  if (isBuyOp && !buy_amount) buy_amount = amount; // Fallback

  // ========= Detect CBPAY vs XDB =========
  const cbpay = isPairCBPAY_XDB(
    op.buying_asset_code, op.buying_asset_type,
    op.selling_asset_code, op.selling_asset_type
  ) ? (isBuyOp ? op.buying_asset_code : op.selling_asset_code) : null;
  const xdb = cbpay === CODE_A ? CODE_B : null;

  // ========= Line for amounts =========
  let buyAmtForLine = isBuyOp ? (buy_amount ?? amount ?? 0) : 0;
  let sellAmtForLine = isBuyOp ? 0 : (amount ?? 0);
  if (cbpay === CODE_B) { // Swap if CBPAY is selling
    [buyAmtForLine, sellAmtForLine] = [sellAmtForLine, buyAmtForLine];
  }

  // ========= Build message =========
  const header = isBuyOp ? "🟢 Nova BUY Offer detectada - CBPAY" : "🔴 Nova SELL Offer detectada - CBPAY";
  const block = `BUY ${f6(buyAmtForLine)} ${cbpay === CODE_A ? CODE_B : CODE_A}\nSELL ${f6(sellAmtForLine)} ${cbpay}`;
  const priceLine = px ? `Price: ${f6(px)}` : "Price: —";
  const link = tx ? `\n🔗 <a href="https://explorer.xdbchain.com/transaction/${tx}">View transaction</a>${ZWSP}` : "";  // CORREÇÃO: /transaction/ em vez de /tx/

  const html = `${header}\n${block}\n${priceLine}${link}`;

  if (DEBUG) {
    console.log({
      type: op.type, buying: op.buying_asset_code, selling: op.selling_asset_code,
      rawPrice, px,
      amount: op.amount, buy_amount: op.buy_amount,
      cbpay, xdb,
      sellAmtForLine, buyAmtForLine,
      tx
    });
  }

  await bot.sendMessage(CHAT_ID, html, { parse_mode: "HTML", disable_web_page_preview: true });
}

// ===== Health server + keep-alive =====
const PORT = Number(process.env.PORT || 8080);
http.createServer((_req: IncomingMessage, res: ServerResponse) => {
  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end("Bot is running.");
}).listen(PORT, () => console.log(`💓 Health server listening on :${PORT}`));

// Evitar deep sleep no Koyeb (ping regular)
const SELF_URL =
  process.env.SELF_URL ||
  (process.env.KOYEB_PUBLIC_DOMAIN ? `https://${process.env.KOYEB_PUBLIC_DOMAIN}/` : "");
async function keepAlive() {
  if (!SELF_URL) return;
  try { await fetch(SELF_URL, { cache: "no-store" }); } catch {}
}
setInterval(keepAlive, 4 * 60 * 1000);

// ===== Loop principal =====
const sleep = (ms: number) => new Promise(res => setTimeout(res, ms));
async function loop() {
  console.log(`🚀 XDB Alerts: watching *CBPAY ↔ XDB* on ${HORIZON_URL}`);
  while (true) {
    try {
      await scanOnce();
      await sleep(8_000);
    } catch (e: any) {
      console.error("loop error:", e.message || e);
      await sleep(5_000);
    }
  }
}
loop();
